﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Proxy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           
            InitializeComponent();
            string cpro = (string)Registry.GetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "ProxyServer", null);
            if (cpro == null)
            {
                label4.Text= "No Proxy";
            }
            else
            {
                label4.Text = cpro;
            }
        }
        static void setProxy(string proxyhost, int proxyEnabled)
        {

            const string keyName = "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";

            Registry.SetValue(keyName, "ProxyServer", proxyhost);
            Registry.SetValue(keyName, "ProxyEnable", proxyEnabled);
                    }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
      
        private void Apply_Click(object sender, EventArgs e)
        {
            try
            {
                setProxy(IP.Text+":"+PORT.Text, 1); string cpro = (string)Registry.GetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "ProxyServer", null);
                label4.Text = cpro; IP.Text = null;
                PORT.Text = null;
                MessageBox.Show("Applied Successfully");
               
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
            }

        private void Disable_Click(object sender, EventArgs e)
        {
            try {
                setProxy("", 0); 
      
                IP.Text = null;
                PORT.Text = null;
                label4.Text = "No Proxy";

                MessageBox.Show("Disabled Succesfully");
               
               

            }
            catch(Exception a) { MessageBox.Show(a.ToString()); }
            }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void IP_TextChanged(object sender, EventArgs e)
        {

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            string rf = (string)Registry.GetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "ProxyServer", null);
            int reff = (int)Registry.GetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "ProxyEnable", null);
            if (reff == 0)
            {
                label4.Text = "No Proxy";
            }
            else
            {
                label4.Text = rf;
            }
        }
    }
}
