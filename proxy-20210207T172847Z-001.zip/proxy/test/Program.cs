﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ProxyToggle
{

    class Program
    {     static void setProxy(string proxyhost, int proxyEnabled)
        {
            
            const string keyName = "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";

            Registry.SetValue(keyName, "ProxyServer", proxyhost);
            Registry.SetValue(keyName, "ProxyEnable",proxyEnabled);

        }

        static void Main(string[] args)
        { setProxy("192.168.1.4:3221", 1); }
}
}